import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/generate', async (req, res) => {
  const { prompt } = req.body;
  const html = `<main><h1 class="text-purple-primary text-4xl">Hello, AI 👋</h1><p>${prompt}</p></main>`;
  const css = `body { background: #0F172A; color: #E2E8F0; } .text-purple-primary{color:#9333EA}`;
  res.json({ html, css, js: "" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Mock server running on port ${PORT}`));