export const PUTER_API_KEY =
  import.meta.env.VITE_PUTER_API_KEY || process.env.PUTER_API_KEY || "";
export const PUTER_APP_ID =
  import.meta.env.VITE_PUTER_APP_ID || process.env.PUTER_APP_ID || "";