
import { Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import TextToWebsite from "./pages/TextToWebsite";
import VisualEditor from "./pages/VisualEditor";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/text-to-website" element={<TextToWebsite />} />
      <Route path="/visual-editor" element={<VisualEditor />} />
    </Routes>
  );
};

export default App;
